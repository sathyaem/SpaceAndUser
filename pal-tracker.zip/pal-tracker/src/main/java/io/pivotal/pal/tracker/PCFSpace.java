package io.pivotal.pal.tracker;

public class PCFSpace {
    public String spaceName;
    public String spaceId;
    public PCFSpace(){}
}
