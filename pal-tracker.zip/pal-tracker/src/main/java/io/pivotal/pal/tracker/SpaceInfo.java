package io.pivotal.pal.tracker;

public class SpaceInfo {
    public String SpaceName;
    public String UserName;
    public SpaceInfo(){}
}
